
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-lightest p-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-light p-10 max-w-md w-full text-center">
        <div className="mb-6">
          <div className="w-20 h-20 bg-blue-light rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-3xl font-display font-bold text-blue">404</span>
          </div>
          <h1 className="text-3xl font-display font-semibold text-gray-darkest mb-4">Page Not Found</h1>
          <p className="text-gray-dark mb-8">
            The page you are looking for doesn't exist or has been moved.
          </p>
        </div>
        <Button 
          className="bg-blue hover:bg-blue-dark text-white transition-all w-full"
          onClick={() => window.location.href = "/"}
        >
          <ExternalLink size={18} className="mr-2" />
          Return to Home
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
