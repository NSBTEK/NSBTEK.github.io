
import React, { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Briefcase } from "lucide-react";

interface JobPosition {
  id: number;
  title: string;
  location: string;
  type: "Full-time" | "Part-time" | "Contract";
  department: string;
  description: string;
}

const jobPositions: JobPosition[] = [
  {
    id: 1,
    title: "Senior Software Engineer",
    location: "New York, NY (Remote)",
    type: "Full-time",
    department: "Engineering",
    description: "We're looking for an experienced software engineer to join our team and help build scalable, reliable software solutions."
  },
  {
    id: 2,
    title: "DevOps Engineer",
    location: "Chicago, IL (Hybrid)",
    type: "Full-time",
    department: "Infrastructure",
    description: "Join our Infrastructure team to help design, implement, and maintain our cloud-based deployment infrastructure."
  },
  {
    id: 3,
    title: "UI/UX Designer",
    location: "San Francisco, CA (Remote)",
    type: "Full-time",
    department: "Design",
    description: "Help create intuitive, engaging user experiences for our enterprise clients' applications."
  },
  {
    id: 4,
    title: "IT Project Manager",
    location: "Boston, MA (On-site)",
    type: "Contract",
    department: "Project Management",
    description: "Lead complex IT projects from inception to completion, ensuring they meet client requirements."
  },
  {
    id: 5,
    title: "Cybersecurity Analyst",
    location: "Austin, TX (Remote)",
    type: "Full-time",
    department: "Security",
    description: "Help protect our client systems by implementing and monitoring security measures."
  }
];

const Careers = () => {
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);

  const handleApply = (id: number) => {
    setSelectedJobId(id);
    // In a real app, this could open a job application form
    window.scrollTo({
      top: document.getElementById('job-details')?.offsetTop || 0 - 100,
      behavior: 'smooth'
    });
  };

  const selectedJob = jobPositions.find(job => job.id === selectedJobId) || jobPositions[0];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow pt-20">
        {/* Hero section */}
        <section className="bg-blue-light py-16 md:py-24">
          <div className="container mx-auto container-padding">
            <div className="max-w-3xl">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-semibold tracking-tight text-gray-darkest mb-6">
                Join Our Team
              </h1>
              <p className="text-lg md:text-xl text-gray-dark mb-8">
                At NSBTEK, we're building a team of passionate professionals who are dedicated to delivering exceptional IT solutions. Explore our open positions and find your next opportunity.
              </p>
              <Button 
                size="lg" 
                className="bg-blue hover:bg-blue-dark text-white transition-all"
                onClick={() => window.scrollTo({
                  top: document.getElementById('open-positions')?.offsetTop || 0 - 100,
                  behavior: 'smooth'
                })}
              >
                View Open Positions
              </Button>
            </div>
          </div>
        </section>

        {/* Why join us section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto container-padding">
            <h2 className="section-title text-center mb-12">Why Join NSBTEK?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 bg-gray-lightest rounded-lg">
                <h3 className="text-xl font-semibold mb-4 text-gray-darkest">Innovative Work</h3>
                <p className="text-gray-dark">
                  Work on cutting-edge projects for industry-leading clients, solving complex challenges with innovative solutions.
                </p>
              </div>
              
              <div className="p-6 bg-gray-lightest rounded-lg">
                <h3 className="text-xl font-semibold mb-4 text-gray-darkest">Growth Opportunities</h3>
                <p className="text-gray-dark">
                  Continuous learning and development, with clear paths for advancement and mentorship from industry experts.
                </p>
              </div>
              
              <div className="p-6 bg-gray-lightest rounded-lg">
                <h3 className="text-xl font-semibold mb-4 text-gray-darkest">Inclusive Culture</h3>
                <p className="text-gray-dark">
                  A diverse, collaborative environment where every team member's contribution is valued and recognized.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Open positions section */}
        <section id="open-positions" className="py-16 bg-gray-lightest">
          <div className="container mx-auto container-padding">
            <h2 className="section-title text-center mb-4">Open Positions</h2>
            <p className="section-subtitle text-center mb-12">
              Explore our current job openings and find your perfect role
            </p>
            
            <div className="overflow-hidden shadow-sm rounded-lg bg-white mb-12">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Position</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {jobPositions.map((job) => (
                    <TableRow key={job.id} className="cursor-pointer hover:bg-gray-50" onClick={() => setSelectedJobId(job.id)}>
                      <TableCell className="font-medium">{job.title}</TableCell>
                      <TableCell>{job.location}</TableCell>
                      <TableCell>{job.type}</TableCell>
                      <TableCell>{job.department}</TableCell>
                      <TableCell className="text-right">
                        <Button 
                          size="sm" 
                          className="bg-blue hover:bg-blue-dark text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleApply(job.id);
                          }}
                        >
                          View & Apply
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </section>
        
        {/* Job details section */}
        <section id="job-details" className="py-16 bg-white">
          <div className="container mx-auto container-padding">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center gap-3 mb-6">
                <Briefcase className="text-blue" />
                <h2 className="text-2xl font-semibold font-display">{selectedJob.title}</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div>
                  <h4 className="text-sm font-medium text-gray-dark mb-1">Location</h4>
                  <p>{selectedJob.location}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-dark mb-1">Employment Type</h4>
                  <p>{selectedJob.type}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-dark mb-1">Department</h4>
                  <p>{selectedJob.department}</p>
                </div>
              </div>
              
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">Job Description</h3>
                <p className="text-gray-dark mb-4">{selectedJob.description}</p>
                <p className="text-gray-dark mb-4">
                  As a {selectedJob.title} at NSBTEK, you'll be part of a dynamic team focused on delivering high-quality solutions for our clients. You'll collaborate with cross-functional teams to design, develop, and implement innovative solutions that meet business requirements.
                </p>
              </div>
              
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">Responsibilities</h3>
                <ul className="list-disc pl-5 space-y-2 text-gray-dark">
                  <li>Work closely with clients to understand their requirements</li>
                  <li>Design and implement scalable solutions</li>
                  <li>Collaborate with cross-functional teams</li>
                  <li>Stay current with industry trends and technologies</li>
                  <li>Provide technical leadership and mentorship</li>
                </ul>
              </div>
              
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">Qualifications</h3>
                <ul className="list-disc pl-5 space-y-2 text-gray-dark">
                  <li>Bachelor's degree in Computer Science or related field</li>
                  <li>5+ years of relevant experience</li>
                  <li>Strong communication and problem-solving skills</li>
                  <li>Experience with modern technologies and frameworks</li>
                  <li>Ability to work in a fast-paced, collaborative environment</li>
                </ul>
              </div>
              
              <div className="text-center">
                <Button size="lg" className="bg-blue hover:bg-blue-dark text-white px-8">
                  Apply Now
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Careers;
