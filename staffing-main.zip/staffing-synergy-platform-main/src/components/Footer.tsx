
import React from 'react';
import { ChevronRight, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-darker text-white pt-16 pb-8">
      <div className="container mx-auto container-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Column 1 - About */}
          <div>
            <h3 className="text-xl font-display font-semibold mb-6">
              NSB<span className="text-blue">TEK</span>
            </h3>
            <p className="text-gray-light mb-6 pr-4">
              Connecting exceptional talent with innovative companies. 
              Our mission is to empower businesses through strategic 
              staffing and IT consulting.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-darkest text-gray-light hover:text-blue transition-colors flex items-center justify-center">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-darkest text-gray-light hover:text-blue transition-colors flex items-center justify-center">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-darkest text-gray-light hover:text-blue transition-colors flex items-center justify-center">
                <Linkedin size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-darkest text-gray-light hover:text-blue transition-colors flex items-center justify-center">
                <Instagram size={18} />
              </a>
            </div>
          </div>
          
          {/* Column 2 - Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Services</h3>
            <ul className="space-y-3">
              {[
                "IT Staffing", 
                "Talent Acquisition", 
                "Strategic Consulting", 
                "Managed IT Services",
                "Digital Transformation",
                "Cybersecurity"
              ].map((service, index) => (
                <li key={index}>
                  <a href="#services" className="text-gray-light hover:text-blue transition-colors flex items-center">
                    <ChevronRight size={16} className="mr-2" />
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Column 3 - Resources */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Resources</h3>
            <ul className="space-y-3">
              {[
                "Case Studies", 
                "Blog", 
                "White Papers", 
                "Industry Reports",
                "Careers",
                "FAQ"
              ].map((resource, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-light hover:text-blue transition-colors flex items-center">
                    <ChevronRight size={16} className="mr-2" />
                    {resource}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Column 4 - Subscribe */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Stay Updated</h3>
            <p className="text-gray-light mb-4">
              Subscribe to our newsletter for industry insights and company news.
            </p>
            <form className="mb-4">
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-grow px-4 py-2 rounded-l-lg text-gray-darkest focus:outline-none"
                />
                <button 
                  type="submit" 
                  className="bg-blue hover:bg-blue-dark text-white px-4 py-2 rounded-r-lg transition-colors"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            </form>
            <p className="text-gray-light text-sm">
              By subscribing, you agree to our Privacy Policy and consent to receive updates.
            </p>
          </div>
        </div>
        
        {/* Divider */}
        <hr className="border-gray-darkest mb-8" />
        
        {/* Bottom footer */}
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-light text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} NSBTEK. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center space-x-6">
            <a href="#" className="text-gray-light hover:text-blue transition-colors text-sm">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-light hover:text-blue transition-colors text-sm">
              Terms of Service
            </a>
            <a href="#" className="text-gray-light hover:text-blue transition-colors text-sm">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
