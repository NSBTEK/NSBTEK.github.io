
import React, { useRef, useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Send } from 'lucide-react';

const Contact = () => {
  const sectionRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };
  
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormState({
        name: '',
        email: '',
        phone: '',
        service: '',
        message: ''
      });
      
      // Reset submission status after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 5000);
    }, 1500);
  };
  
  // Intersection observer to animate elements when in view
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  
  const contactInfo = [
    {
      icon: MapPin,
      title: "Visit us",
      detail: "Princeton, New Jersey"
    },
    {
      icon: Phone,
      title: "Call us",
      detail: "(612) 567-0908"
    },
    {
      icon: Mail,
      title: "Email us",
      detail: "nsbtek@gmail.com"
    }
  ];

  return (
    <section id="contact" className="section-padding bg-white" ref={sectionRef}>
      <div className="container mx-auto container-padding">
        <div className="text-center mb-16">
          <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-light text-blue rounded-full mb-4">
            Get In Touch
          </span>
          <h2 className="section-title">
            Contact Us
          </h2>
          <p className="section-subtitle">
            Ready to transform your IT solutions or find your next opportunity? Reach out today.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Contact form - 3 columns */}
          <div className={`lg:col-span-3 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-light">
              <h3 className="text-2xl font-display font-semibold text-gray-darkest mb-6">
                How can we help?
              </h3>
              
              {isSubmitted ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 mx-auto bg-blue-light rounded-full flex items-center justify-center mb-4">
                    <Send className="text-blue" size={24} />
                  </div>
                  <h4 className="text-xl font-semibold text-gray-darkest mb-2">Message Sent!</h4>
                  <p className="text-gray-dark">Thank you for reaching out. We'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-darker mb-2">
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formState.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-light rounded-lg focus:ring-2 focus:ring-blue focus:border-blue outline-none transition-all"
                        placeholder="Your full name"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-darker mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formState.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-light rounded-lg focus:ring-2 focus:ring-blue focus:border-blue outline-none transition-all"
                        placeholder="your@email.com"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-darker mb-2">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formState.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-light rounded-lg focus:ring-2 focus:ring-blue focus:border-blue outline-none transition-all"
                        placeholder="(123) 456-7890"
                      />
                    </div>
                    <div>
                      <label htmlFor="service" className="block text-sm font-medium text-gray-darker mb-2">
                        Service Interested In
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={formState.service}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-light rounded-lg focus:ring-2 focus:ring-blue focus:border-blue outline-none transition-all"
                        required
                      >
                        <option value="" disabled>Select a service</option>
                        <option value="IT Staffing">IT Staffing</option>
                        <option value="Talent Acquisition">Talent Acquisition</option>
                        <option value="Strategic Consulting">Strategic Consulting</option>
                        <option value="Managed IT Services">Managed IT Services</option>
                        <option value="Digital Transformation">Digital Transformation</option>
                        <option value="Cybersecurity">Cybersecurity</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-darker mb-2">
                      Your Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formState.message}
                      onChange={handleChange}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-light rounded-lg focus:ring-2 focus:ring-blue focus:border-blue outline-none transition-all"
                      placeholder="Tell us about your needs or questions..."
                      required
                    ></textarea>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-blue hover:bg-blue-dark text-white py-3 transition-all"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Sending...
                      </span>
                    ) : (
                      <span>Send Message</span>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </div>
          
          {/* Contact info - 2 columns */}
          <div className={`lg:col-span-2 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
            <div className="bg-gray-lightest rounded-xl p-8 h-full">
              <h3 className="text-2xl font-display font-semibold text-gray-darkest mb-6">
                Contact Information
              </h3>
              
              <div className="space-y-8">
                {contactInfo.map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <div key={index} className="flex">
                      <div className="w-12 h-12 rounded-full bg-blue-light text-blue flex-shrink-0 flex items-center justify-center mr-4">
                        <Icon size={20} />
                      </div>
                      <div>
                        <h4 className="text-lg font-medium text-gray-darkest mb-1">{item.title}</h4>
                        <p className="text-gray-dark">{item.detail}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-12">
                <h4 className="text-lg font-medium text-gray-darkest mb-4">Business Hours</h4>
                <div className="space-y-2 text-gray-dark">
                  <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                  <p>Saturday: 10:00 AM - 2:00 PM</p>
                  <p>Sunday: Closed</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
