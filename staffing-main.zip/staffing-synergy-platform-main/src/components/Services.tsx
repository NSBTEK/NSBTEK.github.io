
import React, { useRef, useEffect, useState } from 'react';
import { Users, Search, Briefcase, Computer, LineChart, Shield } from 'lucide-react';

// Service card component
const ServiceCard = ({ icon: Icon, title, description, isVisible }) => {
  return (
    <div 
      className={`bg-white rounded-xl p-8 shadow-sm border border-gray-light hover:shadow-md hover:border-blue-light transition-all duration-300 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: isVisible ? '0.1s' : '0s' }}
    >
      <div className="w-12 h-12 rounded-full bg-blue-light text-blue flex items-center justify-center mb-6">
        <Icon size={24} />
      </div>
      <h3 className="text-xl font-display font-semibold text-gray-darkest mb-3">{title}</h3>
      <p className="text-gray-dark">{description}</p>
    </div>
  );
};

const Services = () => {
  const sectionRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const services = [
    {
      icon: Users,
      title: "IT Staffing",
      description: "Connect with pre-vetted tech professionals for permanent, contract, or project-based roles."
    },
    {
      icon: Search,
      title: "Talent Acquisition",
      description: "Strategic talent search and placement services tailored to your company's unique needs."
    },
    {
      icon: Briefcase,
      title: "Strategic Consulting",
      description: "Expert guidance to optimize your IT infrastructure, processes, and technology stack."
    },
    {
      icon: Computer,
      title: "Managed IT Services",
      description: "Comprehensive management of your technology needs with proactive monitoring and support."
    },
    {
      icon: LineChart,
      title: "Digital Transformation",
      description: "Navigate complex technological change with expert guidance and implementation support."
    },
    {
      icon: Shield,
      title: "Cybersecurity",
      description: "Protect your business with comprehensive security assessments and implementation."
    }
  ];

  return (
    <section id="services" className="section-padding bg-gray-lightest" ref={sectionRef}>
      <div className="container mx-auto container-padding">
        <div className="text-center mb-16">
          <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-light text-blue rounded-full mb-4">
            Our Services
          </span>
          <h2 className="section-title">
            Comprehensive IT Solutions
          </h2>
          <p className="section-subtitle">
            Tailored services to meet your technology and staffing needs, designed to drive innovation and growth.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard 
              key={index} 
              icon={service.icon} 
              title={service.title} 
              description={service.description}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
