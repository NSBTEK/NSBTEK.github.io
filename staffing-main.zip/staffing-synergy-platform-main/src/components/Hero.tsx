
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Delay animation to allow page to load
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-gradient-to-br from-gray-lightest to-white">
      {/* Background subtle pattern */}
      <div className="absolute inset-0 z-0 opacity-20">
        <div className="absolute right-0 top-1/4 w-72 h-72 bg-blue-light rounded-full filter blur-3xl"></div>
        <div className="absolute left-0 bottom-1/4 w-60 h-60 bg-blue-light rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 md:px-10 lg:px-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left column: Text content */}
          <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="flex flex-col max-w-xl">
              <div className="mb-6">
                <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-light text-blue rounded-full mb-4">
                  IT Consulting & Staffing Solutions
                </span>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-semibold tracking-tight text-gray-darkest leading-tight">
                  Connecting <span className="text-blue">Talent</span> With <span className="text-blue">Opportunity</span>
                </h1>
                <p className="mt-6 text-lg text-gray-dark max-w-lg">
                  We bridge the gap between exceptional IT professionals and forward-thinking companies. Tailored solutions to drive your business forward.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 mt-2">
                <Button size="lg" className="bg-blue hover:bg-blue-dark text-white transition-all">
                  Explore Services
                </Button>
                <Button size="lg" variant="outline" className="border-blue text-blue hover:bg-blue-light transition-all">
                  Hire Talent
                </Button>
              </div>
              
              <div className="mt-12 flex items-center">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gray-lighter flex items-center justify-center">
                      <span className="text-xs font-semibold text-gray-dark">{i}</span>
                    </div>
                  ))}
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-darker">Trusted by 500+ companies</p>
                  <p className="text-sm text-gray-dark">From startups to Fortune 500</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right column: Image */}
          <div className={`relative transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-xl">
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=2940&q=80" 
                alt="IT professionals collaborating" 
                className="w-full h-auto object-cover"
                loading="lazy"
                onLoad={(e) => e.currentTarget.classList.add('loaded')}
              />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -right-8 -bottom-8 w-64 h-64 bg-blue-light/30 backdrop-blur-sm rounded-2xl -z-10"></div>
            <div className="absolute -left-8 -top-8 w-48 h-48 bg-blue-light/20 backdrop-blur-sm rounded-2xl -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
