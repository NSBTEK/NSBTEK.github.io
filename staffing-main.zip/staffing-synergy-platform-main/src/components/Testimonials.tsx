
import React, { useRef, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

// Single testimonial slide
const TestimonialCard = ({ content, author, position, company, isActive }) => {
  return (
    <div className={`absolute inset-0 transition-opacity duration-500 ${isActive ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className="flex flex-col items-center justify-center h-full">
        <div className="w-16 h-16 rounded-full bg-blue-light text-blue flex items-center justify-center mb-8">
          <Quote size={28} />
        </div>
        <p className="text-xl md:text-2xl text-center max-w-3xl mb-8 font-medium text-gray-darker leading-relaxed">
          "{content}"
        </p>
        <div className="text-center">
          <p className="font-semibold text-gray-darkest mb-1">{author}</p>
          <p className="text-gray-dark text-sm">{position}, {company}</p>
        </div>
      </div>
    </div>
  );
};

// Testimonial slider
const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const sectionRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  
  // Testimonial data
  const testimonials = [
    {
      content: "TechStaffPro helped us quickly scale our development team with qualified engineers who hit the ground running. Their consultants integrated seamlessly with our existing team.",
      author: "Sarah Johnson",
      position: "CTO",
      company: "FinTech Innovations"
    },
    {
      content: "Finding specialized IT talent was a struggle until we partnered with TechStaffPro. Their team understood our specific needs and delivered candidates that perfectly matched our culture and technical requirements.",
      author: "Michael Chen",
      position: "VP of Engineering",
      company: "HealthTech Solutions"
    },
    {
      content: "The strategic IT consulting we received transformed our approach to digital operations. They identified critical inefficiencies and implemented solutions that reduced costs by 30%.",
      author: "Alejandra Rodriguez",
      position: "COO",
      company: "Global Logistics Inc."
    }
  ];
  
  // Intersection observer to animate elements when in view
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  
  // Functions to navigate between testimonials
  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };
  
  // Auto-advance testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      nextTestimonial();
    }, 6000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section 
      id="testimonials" 
      className="section-padding bg-white"
      ref={sectionRef}
    >
      <div className={`container mx-auto container-padding transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
        <div className="text-center mb-16">
          <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-light text-blue rounded-full mb-4">
            Client Success Stories
          </span>
          <h2 className="section-title">
            What Our Clients Say
          </h2>
          <p className="section-subtitle">
            Discover how our services have transformed businesses and empowered teams.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto h-80">
          {/* Testimonial slides */}
          {testimonials.map((testimonial, index) => (
            <TestimonialCard
              key={index}
              content={testimonial.content}
              author={testimonial.author}
              position={testimonial.position}
              company={testimonial.company}
              isActive={currentIndex === index}
            />
          ))}
          
          {/* Navigation arrows */}
          <div className="absolute left-0 right-0 bottom-0 flex justify-center space-x-10 pt-6">
            <button 
              onClick={prevTestimonial}
              className="w-10 h-10 flex items-center justify-center rounded-full border border-gray-light text-gray-dark hover:text-blue hover:border-blue transition-all"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={20} />
            </button>
            
            <div className="flex space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    currentIndex === index ? 'bg-blue' : 'bg-gray-light'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            
            <button 
              onClick={nextTestimonial}
              className="w-10 h-10 flex items-center justify-center rounded-full border border-gray-light text-gray-dark hover:text-blue hover:border-blue transition-all"
              aria-label="Next testimonial"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
