
import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from "@/components/ui/button";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/90 backdrop-blur-card shadow-sm' 
          : 'bg-transparent'
      }`}
    >
      <div className="container-padding mx-auto">
        <div className="flex items-center justify-between h-20">
          <a href="#" className="flex items-center gap-2">
            <span className="text-xl font-display font-semibold tracking-tight">
              NSB<span className="text-blue">TEK</span>
            </span>
          </a>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#services" className="text-gray-darker font-medium hover:text-blue transition-all">Services</a>
            <a href="#testimonials" className="text-gray-darker font-medium hover:text-blue transition-all">Testimonials</a>
            <a href="#team" className="text-gray-darker font-medium hover:text-blue transition-all">Our Team</a>
            <a href="/careers" className="text-gray-darker font-medium hover:text-blue transition-all">Careers</a>
            <a href="#contact" className="text-gray-darker font-medium hover:text-blue transition-all">Contact</a>
            <Button size="sm" className="bg-blue hover:bg-blue-dark text-white transition-all">
              Get Started
            </Button>
          </nav>
          
          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-gray-darker" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-light animate-slideDown">
          <div className="container-padding py-4 flex flex-col space-y-4">
            <a 
              href="#services" 
              className="text-gray-darker py-2 transition-all"
              onClick={() => setMobileMenuOpen(false)}
            >
              Services
            </a>
            <a 
              href="#testimonials" 
              className="text-gray-darker py-2 transition-all"
              onClick={() => setMobileMenuOpen(false)}
            >
              Testimonials
            </a>
            <a 
              href="#team" 
              className="text-gray-darker py-2 transition-all"
              onClick={() => setMobileMenuOpen(false)}
            >
              Our Team
            </a>
            <a 
              href="/careers" 
              className="text-gray-darker py-2 transition-all"
              onClick={() => setMobileMenuOpen(false)}
            >
              Careers
            </a>
            <a 
              href="#contact" 
              className="text-gray-darker py-2 transition-all"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </a>
            <Button 
              size="default" 
              className="bg-blue hover:bg-blue-dark text-white w-full justify-center transition-all"
              onClick={() => setMobileMenuOpen(false)}
            >
              Get Started
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
