import React, { useRef, useEffect, useState } from 'react';
import { Linkedin, Twitter, Mail } from 'lucide-react';
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const TeamMember = ({ name, role, bio, links, isVisible, index }) => {
  const delay = index * 100;
  
  const getInitials = (name) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };
  
  return (
    <div 
      className={`flex flex-col transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`} 
      style={{ transitionDelay: isVisible ? `${delay}ms` : '0ms' }}
    >
      <div className="flex justify-center mb-6">
        <Avatar className="w-24 h-24">
          <AvatarFallback className="bg-blue-light text-blue text-lg font-semibold">
            {getInitials(name)}
          </AvatarFallback>
        </Avatar>
      </div>
      <h3 className="text-xl font-semibold font-display text-gray-darkest text-center">{name}</h3>
      <p className="text-blue font-medium text-sm mb-2 text-center">{role}</p>
      <p className="text-gray-dark text-sm text-center mb-4">{bio}</p>
      <div className="flex justify-center space-x-4">
        {links.map((link, i) => {
          const Icon = link.icon;
          return (
            <a 
              key={i}
              href={link.url} 
              className="w-8 h-8 rounded-full bg-gray-lightest flex items-center justify-center text-gray-dark hover:text-blue transition-colors"
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${name}'s ${link.name}`}
            >
              <Icon size={16} />
            </a>
          );
        })}
      </div>
    </div>
  );
};

const Team = () => {
  const sectionRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const teamMembers = [
    {
      name: "Naveen S",
      role: "CEO & Founder",
      bio: "15+ years in tech leadership and talent acquisition for Fortune 500 companies.",
      links: [
        { name: "LinkedIn", icon: Linkedin, url: "#" },
        { name: "Twitter", icon: Twitter, url: "#" },
        { name: "Email", icon: Mail, url: "#" }
      ]
    },
    {
      name: "Babitha",
      role: "CTO",
      bio: "Former Google engineer with expertise in cloud architecture and AI implementations.",
      links: [
        { name: "LinkedIn", icon: Linkedin, url: "#" },
        { name: "Twitter", icon: Twitter, url: "#" },
        { name: "Email", icon: Mail, url: "#" }
      ]
    },
    {
      name: "Diwakar",
      role: "Head of Recruitment",
      bio: "Specialized in tech talent acquisition with a focus on diversity and inclusion.",
      links: [
        { name: "LinkedIn", icon: Linkedin, url: "#" },
        { name: "Twitter", icon: Twitter, url: "#" },
        { name: "Email", icon: Mail, url: "#" }
      ]
    },
    {
      name: "Shilpa",
      role: "CFO",
      bio: "Dedicated to ensuring seamless financial operations and strategic planning.",
      links: [
        { name: "LinkedIn", icon: Linkedin, url: "#" },
        { name: "Twitter", icon: Twitter, url: "#" },
        { name: "Email", icon: Mail, url: "#" }
      ]
    }
  ];

  return (
    <section id="team" className="section-padding bg-gray-lightest" ref={sectionRef}>
      <div className="container mx-auto container-padding">
        <div className="text-center mb-16">
          <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-light text-blue rounded-full mb-4">
            Our Experts
          </span>
          <h2 className="section-title">
            Meet Our Leadership Team
          </h2>
          <p className="section-subtitle">
            Industry veterans committed to connecting top talent with innovative companies.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {teamMembers.map((member, index) => (
            <TeamMember 
              key={index}
              name={member.name}
              role={member.role}
              bio={member.bio}
              links={member.links}
              isVisible={isVisible}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;
